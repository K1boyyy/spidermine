const pages = [...document.querySelectorAll(".page")];

function showPage(id) {
  pages.forEach(p => p.classList.toggle("active", p.id === id));
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function burstHearts(count = 12) {
  const holder = document.getElementById("hearts");
  for (let i = 0; i < count; i++) {
    const h = document.createElement("span");
    h.className = "floating-heart";
    h.textContent = Math.random() > .5 ? "❤️" : "💙";
    h.style.left = `${10 + Math.random() * 80}%`;
    h.style.top = `${55 + Math.random() * 30}%`;
    h.style.animationDelay = `${Math.random() * .5}s`;
    holder.appendChild(h);
    setTimeout(() => h.remove(), 3300);
  }
}

// DATE INPUT
const dateInputs = [...document.querySelectorAll("#dateInputs input")];
dateInputs.forEach((input, index) => {
  input.addEventListener("input", () => {
    input.value = input.value.replace(/\D/g, "").slice(0, 1);
    if (input.value && index < dateInputs.length - 1) dateInputs[index + 1].focus();
  });
  input.addEventListener("keydown", e => {
    if (e.key === "Backspace" && !input.value && index > 0) dateInputs[index - 1].focus();
  });
});

document.getElementById("dateBtn").addEventListener("click", () => {
  const code = dateInputs.map(i => i.value).join("");
  const hint = document.getElementById("dateHint");
  if (code === "220224") {
    hint.textContent = "";
    burstHearts(10);
    setTimeout(() => showPage("page-love"), 500);
  } else {
    hint.textContent = "hmm... that's not our date, mas 🕷️";
    dateInputs.forEach(i => {
      i.animate([
        { transform: "translateX(0)" },
        { transform: "translateX(-5px)" },
        { transform: "translateX(5px)" },
        { transform: "translateX(0)" }
      ], { duration: 300 });
    });
  }
});

document.getElementById("yesBtn").addEventListener("click", () => {
  burstHearts(22);
  setTimeout(() => showPage("page-letter"), 500);
});

document.getElementById("noBtn").addEventListener("click", () => {
  document.getElementById("noHint").textContent = "ERROR. that option is temporarily unavailable 😭";
  setTimeout(() => showPage("page-404"), 650);
});

document.getElementById("backLoveBtn").addEventListener("click", () => {
  showPage("page-love");
});

document.querySelectorAll("[data-next]").forEach(btn => {
  btn.addEventListener("click", () => showPage(btn.dataset.next));
});

// MUSIC
const audio = document.getElementById("ourSong");
document.getElementById("musicBtn").addEventListener("click", () => {
  if (audio.src.endsWith("our-song.mp3")) {
    document.querySelector(".audio-note").textContent =
      "Tambahkan lagu milikmu sendiri ke music/our-song.mp3 untuk mengaktifkan player ini ♡";
    return;
  }
  audio.paused ? audio.play() : audio.pause();
});

// GAME
let score = 0;
let timeLeft = 20;
let gameInterval = null;
let spawnInterval = null;
const board = document.getElementById("gameBoard");
const startGame = document.getElementById("startGame");
const scoreEl = document.getElementById("score");
const timerEl = document.getElementById("timer");
const gameMessage = document.getElementById("gameMessage");
const player = document.getElementById("player");
const gameNext = document.getElementById("gameNext");

let playerX = 50;

function movePlayer(x) {
  const rect = board.getBoundingClientRect();
  const percent = ((x - rect.left) / rect.width) * 100;
  playerX = Math.max(7, Math.min(93, percent));
  player.style.left = playerX + "%";
}

board.addEventListener("pointermove", e => {
  if (e.pointerType === "mouse" || e.pointerType === "pen") movePlayer(e.clientX);
});
board.addEventListener("touchmove", e => {
  if (e.touches[0]) movePlayer(e.touches[0].clientX);
}, {passive:true});

function spawnHeart() {
  const heart = document.createElement("button");
  heart.className = "heart-target";
  heart.textContent = Math.random() > .5 ? "❤️" : "💙";
  heart.style.left = `${5 + Math.random() * 90}%`;
  heart.style.top = `${8 + Math.random() * 78}%`;
  heart.setAttribute("aria-label", "catch heart");
  heart.addEventListener("click", () => {
    score++;
    scoreEl.textContent = score;
    burstHearts(2);
    heart.remove();
    if (score >= 10) winGame();
  });
  board.appendChild(heart);
  setTimeout(() => heart.remove(), 1400);
}

function clearGame() {
  board.querySelectorAll(".heart-target").forEach(h => h.remove());
  clearInterval(gameInterval);
  clearInterval(spawnInterval);
}

function startGameNow() {
  clearGame();
  score = 0;
  timeLeft = 20;
  scoreEl.textContent = "0";
  timerEl.textContent = "20";
  gameMessage.textContent = "";
  gameNext.classList.add("hidden");
  startGame.classList.add("hidden");

  gameInterval = setInterval(() => {
    timeLeft--;
    timerEl.textContent = timeLeft;
    if (timeLeft <= 0) loseGame();
  }, 1000);

  spawnInterval = setInterval(spawnHeart, 700);
  for (let i = 0; i < 3; i++) spawnHeart();
}

function winGame() {
  clearGame();
  gameMessage.innerHTML = "🏆 WINNER!<br>menang di game dan menang di hati dede. ❤️";
  gameNext.classList.remove("hidden");
  burstHearts(28);
}

function loseGame() {
  clearGame();
  gameMessage.textContent = "NOOO 😭 belum menang... coba lagi, superhero!";
  startGame.classList.remove("hidden");
}

startGame.addEventListener("click", startGameNow);
gameNext.addEventListener("click", () => showPage("page-final"));

// PHOTO FALLBACK
const couplePhoto = document.getElementById("couplePhoto");
couplePhoto.addEventListener("load", () => {
  document.querySelector(".photo-frame").classList.add("has-photo");
});
couplePhoto.addEventListener("error", () => {
  document.querySelector(".photo-frame").classList.remove("has-photo");
});
